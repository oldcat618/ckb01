#!/bin/sh
upg_mng -p &

