#! bin/sh

do_loop_monitor(){
        while [ 1 ]
        do
                ps | grep ftmd | grep -v grep
                [ $? -ne 0 ] && { /etc/appstart/ftmd_start.sh & }
                sleep 3
        done
}

do_loop_monitor &
