#!/bin/sh

rm_modules_ko() {
        local keep_kos="nf_conntrack_ftp.ko nf_conntrack_h323.ko nf_conntrack_rtsp.ko nf_conntrack_sip.ko nf_nat_ftp.ko nf_nat_h323.ko nf_nat_rtsp.ko nf_nat_sip.ko"

        for i in `ls /lib/modules/4.4.60`; do
                echo "$keep_kos" | grep -q "$i" || rm -f /lib/modules/4.4.60/$i;
        done
}

rm_wifi_script() {
        local keep_file="qca-wifi-modules qcacommands_ol_radio.xml qcacommands_vap.xml qcawifi_countrycode.txt tools_config wifi_nss_hk_olnum wifi_nss_olcfg wifi_nss_olnum"

        for i in `ls /lib/wifi/`; do
                echo "$keep_file" | grep -q "$i" || rm -rf /lib/wifi/$i;
        done
}

rm_wifi_firmware() {
        # wait wifi load over
        while true; do
                lsmod | grep -q "wifi" || { sleep 1; continue; }
                ifconfig -a | grep -q "wifi" || { sleep 1; continue; }
                break;
        done
        rm -rf /lib/firmware/
        rm -rf /cfg
        rm_wifi_script
}

sleep 60
rm_modules_ko
rm_wifi_firmware
