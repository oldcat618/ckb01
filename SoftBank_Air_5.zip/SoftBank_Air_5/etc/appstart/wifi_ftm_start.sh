#!/bin/sh

WIFI_BD_EP_FILE_NAME=/firmware/image/bdwlan.elf.ep
WIFI_BD_FILE_NAME=/firmware/image/bdwlan_otp.elf

#放开/firmware/image下可读写
if [ -d "/firmware/image" ]; then
        mount -o remount -rw /firmware
fi

if [ -e "$WIFI_BD_EP_FILE_NAME" ];then
	echo "replace file to $WIFI_BD_EP_FILE_NAME"
	mv $WIFI_BD_EP_FILE_NAME $WIFI_BD_FILE_NAME
	rm -f $WIFI_BD_EP_FILE_NAME
	sync
fi

if [ ! -e "$WIFI_BD_FILE_NAME" ];then
	echo "ERR! $WIFI_BD_FILE_NAME is not exist"
	exit
fi

insmod /lib/modules/$(uname -r)/extra/wlan.ko
while :
do
		ifconfig -a | grep wlan0
		[ $? -eq  0 ] && break
		sleep 2
done

ifconfig wlan0 up
