rm -f /etc/TZ
mkdir -p  /oatptmp/timezone/
ommng &