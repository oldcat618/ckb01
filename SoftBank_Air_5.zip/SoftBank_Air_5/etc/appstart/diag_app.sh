/usr/sbin/diag_app_start_main
#/usr/sbin/diag_socket_app -a 192.168.1.254 &
/usr/sbin/oem_diag_main &
