#!/bin/sh

#sleep 3
modem_mng &

