sleep 30 
echo 5 > /sys/module/wlan/parameters/con_mode 

ftmdaemon -n -dd &
