#!/bin/sh

start_service() {
    local pid=""

    logger -t "wifi" "start wifi service"
    for i in `seq 1 15`; do
        ps | grep -v grep | grep -q "/sbin/wifi detect" && sleep 1 || break
    done
    [ -e  /usr/lib/oppo/wifi_thermal_config.sh ] && /usr/lib/oppo/wifi_thermal_config.sh

    pid=`pidof wifi_serv`
    if [ -n "$pid" ]; then
        logger -t "wifi" "wifi service already started"
    else
        wifi_serv 2>/dev/null 1>&2 &
        logger -t "wifi" "wifi service started"
    fi
}

start_service
