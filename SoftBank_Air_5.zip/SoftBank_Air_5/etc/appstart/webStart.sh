#!/bin/sh
#login start


[ ! -e /data/database/user_account_info.json ] && cp -af /etc/configure/user_account_info.json /data/database/
[ ! -e /data/database/language.json ] && cp -af /etc/configure/language.json /data/database/
cp -af /etc/configure/white_token_list.json   /data/database/
cp -af /etc/configure/white_api.json   /data/database/
cp -af /etc/configure/non_encry_api.json   /data/database/

start_generate_opensource_notice(){
    mkdir -p /var/run/webStatic
    mkdir -p /var/run/webStatic/opensourceStatic

    tar -zxvf /etc/opensource_notice.tar.gz -C /var/run/webStatic/opensourceStatic
    appDir=`ls -v /var/run/webStatic/opensourceStatic/application`
    startLinkStr="<p class='opensource-link-a'><a href='/static/copyrightPage/opensource/application/"
    startEndLink="'>"
    endLink="</a></p>"
    startDescText="open source software notice for application components-"
    cat /etc/webui/static/copyrightPage/opensourceSummaryStart.html > /var/run/webStatic/opensourceStatic/opensourceSummary.html

    for file in $appDir;
    do
            indexNum=`echo $file|awk -F '.' '{print $1}'`
            allText=$startDescText$indexNum
            allLink=$startLinkStr$file$startEndLink$allText$endLink
            echo $allLink >> /var/run/webStatic/opensourceStatic/opensourceSummary.html
    done

    platDir=`ls -v /var/run/webStatic/opensourceStatic/platform`
    startLinkStr="<p class='opensource-link-a'><a href='/static/copyrightPage/opensource/platform/"
    startEndLink="'>"
    endLink="</a></p>"
    startDescText="open source software notice for chipset components-"

    for file in $platDir;
    do
            indexNum=`echo $file|awk -F '.' '{print $1}'`
            allText=$startDescText$indexNum
            allLink=$startLinkStr$file$startEndLink$allText$endLink
            echo $allLink >>  /var/run/webStatic/opensourceStatic/opensourceSummary.html
    done
    cat /etc/webui/static/copyrightPage/opensourceSummaryEnd.html >> /var/run/webStatic/opensourceStatic/opensourceSummary.html
    ln -sf /var/run/webStatic/opensourceStatic /etc/webui/static/copyrightPage/opensource
}

start_generate_opensource_notice

#cp -af /etc/configure/privatekey.pem   /data/database/
#cp -af /etc/configure/publickey.pem   /data/database/

mkdir -p /oatptmp/pem

userLogin_mng &

#ln img
# cd /etc/webui
# ln -sf /odata/webui/img img

#start debug

#spwan cgi start
# spawn-fcgi -a 127.0.0.1 -p 8088 -f webCgi -n 
nice -10 spawn-fcgi -s /oatptmp/webCgi.sock -f webCgi -U nobody &

start_nginx()
{
    #nginx start
    #$1 listen interface
    mkdir -p /var/run/nginx/logs
    while true 
    do
       listen_ipv4=`ifconfig  $1 | grep "inet addr" | cut -d ":" -f 2 | cut -d " " -f 1`
       fixed_ip_str=`ip addr show dev bridge0 | grep "inet" | grep "172" | cut -d "/" -f 1`
       fixed_ip=${fixed_ip_str#*inet}
    #    listen_ipv6=`ifconfig  $1 | grep "inet6 addr" | grep "Link" | cut -d "/" -f 1 | cut -d " " -f 13`
    #    [ -n "$listen_ipv4" -a -n "$listen_ipv6" ] && break
       [ -n "$listen_ipv4" -a -n "$fixed_ip" ] && break
       sleep 2
    done
    cp /etc/nginx/nginx.conf.default /oatptmp/nginx.conf
    if [ "$listen_ipv4" != "" ];then
        sed -i "s/listen_ipv4_addr/${listen_ipv4}/g" /oatptmp/nginx.conf
    else
        sed -i "s/listen_ipv4_addr://g" /oatptmp/nginx.conf
    fi
    # if [ "$listen_ipv6" != "" ];then
        # sed -i "s/listen_ipv6_addr/${listen_ipv6}/g" /oatptmp/nginx.conf
    # else
        # sed -i "s/listen_ipv6_addr/::/g" /oatptmp/nginx.conf
    # fi
    nginx -c /etc/nginx/nginx.conf -p /var/run/nginx
}

start_nginx bridge0 &