#!/bin/sh

for i in dial_cfg.json user_apn_cfg.json nas_cfg.json
do
    [ ! -f "/data/database/$i" ] && cp /etc/configure/$i /data/database/$i
done

# 升级平滑适配, 删除旧的配置文件名
oatprsync -d 169.254.10.2 /data/IPQ/data/database/mode_switch_user_cfg.json
oatprsync -d 169.254.10.2 /data/IPQ/data/database/mode_switch_user_cfg.json.bak

dialup_mng &
