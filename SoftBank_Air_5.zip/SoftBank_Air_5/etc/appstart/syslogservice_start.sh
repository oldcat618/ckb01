echo "start syslogservice"
mkdir -p /data/syslog/
syslogservice &
