cli_serv &
#cli_telnet_sfn &
