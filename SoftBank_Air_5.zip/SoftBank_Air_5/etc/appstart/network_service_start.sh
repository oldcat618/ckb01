#!/bin/sh

iptables -t filter -F
iptables -t nat -F
iptables -t mangle -F
brctl delif br-lan eth0
brctl delif br-lan eth1
ifconfig br-lan down && brctl delbr br-lan
echo 1 > /proc/sys/net/ipv6/conf/all/forwarding

sysctl net.ipv4.neigh.default.gc_thresh1=1
sysctl net.ipv4.neigh.default.gc_thresh2=512
sysctl net.ipv4.neigh.default.gc_thresh3=1024

network_service &
connect_mng &
iptables -t nat -I POSTROUTING -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
iptables -w -t filter -A OUTPUT -o rmnet_data0 -p icmp --icmp-type 3 -j DROP
/etc/init.d/conntrackd stop
/etc/init.d/breakpad stop
#等待dhcp服务启动完成或者20s后打开网口
wait_count=0
while true
do
    let wait_count++
    pidof dhcps-bridge0
    [ "$?" == 0 -o "$wait_count" == 20 ] && break
    sleep 1
done
ssdk_sh debug phy set 8 0 0x8000
ssdk_sh debug phy set 9 0 0x8000

echo 16000 > /proc/sys/dev/nss/n2hcfg/n2h_high_water_core0
tc qdisc add dev bridge0 root nsspfifo limit 4096 accel_mode 0 set_default
