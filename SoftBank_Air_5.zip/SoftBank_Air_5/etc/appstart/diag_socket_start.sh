#!/bin/sh
diag_socket_guarder(){
        while :
        do
                sleep 10
                pgrep diag_socket_app >/dev/null
                [ $? -ne 0 ] && {
                        echo "diag_socket_log exited, now restart it!" >>/tmp/diag_sock.log
                        diag_socket_app -a "192.168.99.254" 2 >/dev/null &
                }
        done
}
diag_socket_guarder &
