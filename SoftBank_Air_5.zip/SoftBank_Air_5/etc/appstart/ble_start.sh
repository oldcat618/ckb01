#!/bin/sh

FIRMWARE_PATH="/usr/lib/firmware/BLE/"

try_upgrade_ble() {
	local chip_ver=`bledfu /dev/ttyMSM1 115200 version 2>/dev/null | awk -F":" '{print $2}'`
	local file_name=`ls $FIRMWARE_PATH | tail -n 1`
	local file_ver=`echo $file_name | awk -F"_" '{print $2}'`

	[ "$chip_ver" == "$file_ver" ] && return 0;
	echo "BLE old version:$chip_ver need upgrade to version:$file_ver"
	bledfu /dev/ttyMSM1 115200 ${FIRMWARE_PATH}/${file_name}
}

ble_start() {
	echo "start blemng"
	blemng 2>/dev/nul 1>&2 &
	return 0;
}

killall -q blemng && sleep 1
killall -q bledfu && sleep 1

try_upgrade_ble
ble_start
