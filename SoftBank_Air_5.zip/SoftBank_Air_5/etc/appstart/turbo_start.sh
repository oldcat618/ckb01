#!/bin/sh

start_service() {
    local pid=""

    pid=`pidof turbo_proto`
    if [ -n "$pid" ]; then
        logger -t "turbo" "turbo service already started"
    else
        turbo_proto 2>/dev/null 1>&2 &
        logger -t "turbo" "turbo service started"
    fi
}

unload_ecm_sfe() {
    if [ -d /sys/module/ecm ]; then
        rmmod ecm
        sleep 1
    fi
    if [ -d /sys/module/shortcut_fe_drv ]; then
        rmmod shortcut-fe-drv
        sleep 1
    fi
    if [ -d /sys/module/shortcut_fe ]; then
        rmmod shortcut-fe
        sleep 1
    fi
}

load_ecm_sfe() {
    local kernel_version=$(uname -r)
    [ -e "/lib/modules/$kernel_version/shortcut-fe.ko" ] && {
        insmod shortcut-fe
    }

    [ -e "/lib/modules/$kernel_version/shortcut-fe-drv.ko" ] && {
        insmod shortcut-fe-drv
    }

    [ -e "/lib/modules/$kernel_version/shortcut-fe-cm.ko" ] && {
        insmod shortcut-fe-cm
    }
    [ -e "/lib/modules/$kernel_version/ecm.ko" ] && {
        insmod ecm
    }
}

unload_ecm_sfe
load_ecm_sfe
start_service
