#!/bin/sh
killall -9 cli_serv
killall -9 cmdworkermod
sleep 1
