#!/bin/sh
killall miniupnpd
sleep 2
reboot_oem
