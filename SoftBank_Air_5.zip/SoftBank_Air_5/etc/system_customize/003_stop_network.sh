#!/bin/sh
ifconfig bridge0 down
