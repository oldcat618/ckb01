#!/bin/sh

do_logmask() {
    for file in $(find $1); do
        if [ ! -d ${file} ]; then
            #echo "do log mask:"$file #在此处处理文件即可
            servicelogctl masklog $file ${file}_mask
            mv ${file}_mask ${file}
        fi
    done
}

export_system_log() {
    x55_ip=169.254.10.2
    systemlogFile=/oatptmp/systemlog.tar
    oatprsync -e ${x55_ip} "/etc/system_customize/export_x55_system_log.sh ${systemlogFile}"
    oatprsync -g ${x55_ip} ${systemlogFile} ${systemlogFile}
    oatprsync -e ${x55_ip} "rm -f ${systemlogFile}"
    tar xf ${systemlogFile} -C $1
    rm -f ${systemlogFile}
}

export_snapshot() {
    cp /oatptmp/bootup_kmsg.log $1
    /usr/lib/otransh/network_diags.sh $1
    /usr/lib/otransh/system_photo.sh $1 
    /usr/lib/owifi/logcollect.sh $1
    do_logmask $1
}

copy_servicelog() {
    cp -rf $1/* $2
}

main() {
    LogExportTempPath=/oatptmp/localtmplog
    mkdir -p ${LogExportTempPath}

    #1. export x55 log
    mkdir -p ${LogExportTempPath}/systemlog
    export_system_log ${LogExportTempPath}/systemlog

    #2 copy servicelog to LogExportTempPath
    copy_servicelog $1 ${LogExportTempPath}

    #3. export ipq log
    mkdir -p ${LogExportTempPath}/snapshot
    export_snapshot ${LogExportTempPath}/snapshot

    tar -C ${LogExportTempPath} -cf $2 .
    rm -rf ${LogExportTempPath}
}

#$1 for servicelog path, $2 for export log file path
main $1 $2
