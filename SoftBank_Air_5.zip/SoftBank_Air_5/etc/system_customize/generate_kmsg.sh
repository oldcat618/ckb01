#!/bin/sh
x55_ip=169.254.10.2
tmpfile=/oatptmp/kmsg.txt
oatprsync -e $x55_ip "dmesg > $tmpfile"
oatprsync -g $x55_ip $tmpfile $tmpfile
oatprsync -e $x55_ip "rm $tmpfile"
echo "####################################x55###############################################">$1
cat $tmpfile >>$1
echo "####################################ipq###############################################">>$1
dmesg >>$1
rm -rf $tmpfile