#!/bin/sh
x55_ip=169.254.10.2
oatprsync -e $x55_ip "/usr/lib/oppo/get_reboot_reason"
oatprsync -g $x55_ip /data/reboot_reason.txt /data/reboot_reason.txt