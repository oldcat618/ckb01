#!/bin/sh

x55_ip=169.254.10.2
filepath=/oatptmp/servicelog
file=servielog.tar
oatprsync -e $x55_ip "mkdir -p $filepath"
oatprsync -e $x55_ip "servicelogctl Flush"
oatprsync -e $x55_ip "tar -cf $filepath/$file /data/log /data/ipqlog"
oatprsync -g $x55_ip $1 $filepath/$file
oatprsync -e $x55_ip "rm -rf  $filepath"