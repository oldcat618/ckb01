#!/bin/sh

stop_wifi_service() {
    local allifaces="ath0 ath01 ath1 ath11"

    touch /tmp/.upgrading
    logger -t "wifi" "System is upgrading, stop wifi service"

    for i in $allifaces; do
        ifconfig $i down 2>/dev/null 1>&2
    done
}

stop_wifi_service
