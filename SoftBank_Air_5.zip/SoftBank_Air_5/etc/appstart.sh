#! /bin/sh
# PATH=/sbin/xxx:$PATH
PATH=/usr/lib/otransh:$PATH

date -s "2021-01-01 0:0:0"

#replace /dev/console
rm -f /dev/console
ln -s /dev/null /dev/console

enable_debug_feature()
{
	[ -e /etc/debug_feature/$1 ] && /etc/debug_feature/$1
}

# redirect stdout/stderr to /dev/null
exec 1>/dev/null 2>&1

config_mhi_sw0()
{
	for i in $(seq 1 60)
	do
		echo $i > /tmp/rmnet_mhi_sw0.config
		ifconfig rmnet_mhi_sw0 169.254.10.1 netmask 255.255.255.0 up
		ipaddr=`ifconfig rmnet_mhi_sw0 | grep 169`
		if [ -n "$ipaddr" ]; then
			break
		fi
		sleep 2
	done
}

config_mhi_sw0

#存取coredump到flash
mkdir -p /data/coredump
mkdir -p /data/database
mkdir -p /oatptmp/rtconfigure
mkdir -p /data/lastboot
mkdir -p /data/totaluptime
#loop until oatprsyncd ready
for i in $(seq 1 15)
do
	echo $i > /tmp/rsyncd.test
	oatprsync -p 169.254.10.2 /tmp/rsyncd.test /var/run/rsyncd.test
	if [ $? -eq 0 ]; then
		break
	fi
	sleep 2
done

/etc/appstart/servicelog_start.sh &

eqflag get
if [ $? -eq 0 ]; then
	brctl addbr br-lan
	ifconfig eth0 up
	ifconfig eth1 up
	brctl addif br-lan eth0
	brctl addif br-lan eth1
        ifconfig br-lan 192.168.1.1 netmask 255.255.255.0 up
        # turn on phy
        ssdk_sh debug phy set 8 0 0x8000
        ssdk_sh debug phy set 9 0 0x8000
	sleep 1

	# diag and equip
	/etc/appstart/diag_app.sh &
	/etc/appstart/ftmd_start.sh &

	#multifota 
	multifota -m factory -i br-lan &

    # upgrade
    /etc/appstart/upgmng_start.sh &
	/etc/appstart/debug_tools_start.sh br-lan &

	#light green up
        [ -f "/usr/lib/oppo/DFT/led_dft" ] && {
		/usr/lib/oppo/DFT/led_dft 1 0x100
                /usr/lib/oppo/DFT/led_dft 1 0x201
		/usr/lib/oppo/DFT/led_dft 1 0x500
	}

	# monitoring the ftmd program
	/etc/appstart/app_monitor.sh &
else
	# Framework开机脚本,servicedeameo
	/etc/appstart/servicedaemon_start.sh &
	/etc/appstart/syslogservice_start.sh &
	# 启动业务脚本
	/etc/appstart/equip_start.sh &
	nice -n -10 /etc/appstart/network_service_start.sh &
	/etc/appstart/ethwan_start.sh &
	nice -n -10 /etc/appstart/modem_start.sh &
	nice -n -10 /etc/appstart/dialup_start.sh &
	/etc/appstart/wifi_start.sh &
	/etc/appstart/ble_start.sh &
	#/etc/appstart/sms_start.sh &

	/etc/appstart/upgmng_start.sh &
	#/etc/appstart/cwmp_start.sh &
	/etc/appstart/device_start.sh &
	/etc/appstart/ommng_start.sh &
	#/etc/appstart/samba_start.sh &
	#/etc/appstart/antennactrl_start.sh &
	/etc/appstart/fota_start.sh &
	/etc/appstart/timeservice_start.sh &
	/etc/appstart/webStart.sh &
	/etc/appstart/cli_start.sh &
	/etc/appstart/tftpservice_start.sh &
	/etc/appstart/blacklist_start.sh &
	/etc/appstart/turbo_start.sh &
	# 启动内存清理脚本
	/etc/appstart/memory_clean.sh &
	# debug feture enable
	enable_debug_feature debug_feature_start.sh
fi
