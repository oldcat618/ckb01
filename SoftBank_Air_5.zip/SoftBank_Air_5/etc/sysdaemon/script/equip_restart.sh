killall -9 equip
equip &
