killall -9 ommng
rm -f /etc/TZ
mkdir -p  /oatptmp/timezone/
ommng &