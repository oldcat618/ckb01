killall -9 tftpservice
tftpservice &