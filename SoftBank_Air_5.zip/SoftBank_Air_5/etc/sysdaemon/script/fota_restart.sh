killall -9 fota
fota &