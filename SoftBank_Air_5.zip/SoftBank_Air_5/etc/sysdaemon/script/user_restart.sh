

killall -9 userLogin_mng 
userLogin_mng &
