killall -9 transfermng
killall -9 blacklist_serv
transfermng &
blacklist_serv &
