killall -9 ledmng
ledmng &