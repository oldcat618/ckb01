#!/bin/sh
killall -9 connect_mng
connect_mng &