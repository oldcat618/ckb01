#!/bin/sh

# kill old process
killall wifi_serv; sleep 1;
for i in `seq 1 3`; do
    pidof wifi_serv 2>/dev/null 1>&2 || break
    killall -9 wifi_serv 2>/dev/null 1>&2; sleep 3
done

# start new process
wifi_serv 2>/dev/null 1>&2 &
