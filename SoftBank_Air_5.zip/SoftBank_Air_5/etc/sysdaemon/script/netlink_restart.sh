killall -9 netlinkevtmng
netlinkevtmng &