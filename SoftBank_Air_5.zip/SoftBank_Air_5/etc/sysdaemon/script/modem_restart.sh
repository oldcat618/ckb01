#!/bin/sh

killall -9 modem_mng

sleep 1

modem_mng &