killall -9 servicelog
servicelog &
