
#!/bin/sh
killall -9 upg_mng
upg_mng -p &
