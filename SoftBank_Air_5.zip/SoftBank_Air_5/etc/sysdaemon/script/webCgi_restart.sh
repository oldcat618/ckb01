
killall -9 webCgi
killall -9 nginx


nice -10 spawn-fcgi -s /oatptmp/webCgi.sock -f webCgi -U nobody &

nginx -c /etc/nginx/nginx.conf -p /var/run/nginx &