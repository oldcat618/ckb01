killall -9 syslogservice
syslogservice &