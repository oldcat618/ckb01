#!/bin/sh

tzfile=/etc/configure/zoneinfo.tar.gz
if [ "$1" == "-ltz" ];then
	tar -zxvf $tzfile -C /oatptmp/
	if [ "$2" == "1" ];then
		echo "set daylight mode"
		cp /oatptmp/zoneinfo/zoneinfo-dst/$3 /oatptmp/timezone/localtime
	else
		cp /oatptmp/zoneinfo/zoneinfo-ndst/$3 /oatptmp/timezone/localtime
	fi
	rm -rf /oatptmp/zoneinfo
elif [ "$1" == "-rt" ];then
	x55_ip=169.254.10.2
	oatprsync -e $x55_ip "date -s $2"
elif [ "$1" == "-rtz" ];then
	x55_ip=169.254.10.2
	oatprsync -e $x55_ip "tar -zxvf $tzfile -C /oatptmp/"
	if [ "$2" == "1" ];then
		echo "set daylight mode"
		oatprsync -e $x55_ip "cp  /oatptmp/zoneinfo/zoneinfo-dst/$3 /oatptmp/timezone/localtime"
	else
		oatprsync -e $x55_ip "cp  /oatptmp/zoneinfo/zoneinfo-ndst/$3 /oatptmp/timezone/localtime"
	fi
	rm -rf /oatptmp/zoneinfo
else
	echo "Usage:"
	echo "  set_time.sh -ltz daylight[1/0] timezone[Asia/Shanghai]"
	echo "  set_time.sh -rt 2020.10.20-00:00:00"
	echo "  set_time.sh -rtz daylight[1/0] timezone[Asia/Shanghai]"
fi
